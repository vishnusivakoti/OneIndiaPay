package com.OneIndiaPay.controller;

import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.entity.User;
import com.OneIndiaPay.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {
    
    private final UserService userService;
    
    @PostMapping("/register")
    public ResponseEntity<UserResponse> registerUser(
            @Valid @RequestBody UserRegistrationRequest request) {
        
        UserResponse response = userService.registerUser(request, 10000001L);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @PostMapping("/register/{parentId}")
    public ResponseEntity<UserResponse> registerUserByParent(
            @PathVariable Long parentId,
            @Valid @RequestBody UserRegistrationRequest request) {
        
        request.setParentId(parentId);
        UserResponse response = userService.registerUser(request, parentId);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable Long id) {
        UserResponse response = userService.getUserById(id, 10000001L, User.Role.ADMIN);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/hierarchy/{parentId}")
    public ResponseEntity<List<UserResponse>> getUserHierarchy(@PathVariable Long parentId) {
        List<UserResponse> response = userService.getUserHierarchy(parentId, 10000001L, User.Role.ADMIN);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserRegistrationRequest request) {
        
        UserResponse response = userService.updateUser(id, request, 10000001L, User.Role.ADMIN);
        return ResponseEntity.ok(response);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deactivateUser(@PathVariable Long id) {
        userService.deactivateUser(id, 10000001L, User.Role.ADMIN);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/exists/{userId}")
    public ResponseEntity<Boolean> userExists(@PathVariable Long userId) {
        Boolean exists = userService.userExists(userId);
        return ResponseEntity.ok(exists);
    }
}