package com.OneIndiaPay.service;

import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.config.EncryptionService;
import com.OneIndiaPay.entity.User;
import com.OneIndiaPay.exception.*;
import com.OneIndiaPay.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class UserService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EncryptionService encryptionService;
    
    public UserResponse registerUser(UserRegistrationRequest request, Long currentUserId) {
        validateRegistrationRequest(request, currentUserId);
        
        User user = new User();
        user.setId(generateUniqueUserId());
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setPan(encryptionService.encrypt(request.getPan()));
        user.setAadhaar(encryptionService.encrypt(request.getAadhaar()));
        user.setAddress(request.getAddress());
        user.setRole(request.getRole());
        user.setParentId(request.getParentId());
        user.setStatus(User.UserStatus.ACTIVE);
        
        User savedUser = userRepository.save(user);
        return mapToUserResponse(savedUser);
    }
    
    public UserResponse getUserById(Long id, Long currentUserId, User.Role currentUserRole) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException(id));
        
        validateUserAccess(user, currentUserId, currentUserRole);
        return mapToUserResponse(user);
    }
    
    public List<UserResponse> getUserHierarchy(Long parentId, Long currentUserId, User.Role currentUserRole) {
        validateHierarchyAccess(parentId, currentUserId, currentUserRole);
        
        List<User> users = userRepository.findByParentId(parentId);
        return users.stream()
            .map(this::mapToUserResponse)
            .collect(Collectors.toList());
    }
    
    public UserResponse updateUser(Long id, UserRegistrationRequest request, Long currentUserId, User.Role currentUserRole) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException(id));
        
        validateUserAccess(user, currentUserId, currentUserRole);
        
        if (user.getStatus() != User.UserStatus.ACTIVE) {
            throw new UserStatusException(user.getStatus());
        }
        
        // Check if email/phone already exists for other users
        if (!user.getEmail().equals(request.getEmail()) && userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("email", request.getEmail());
        }
        
        if (!user.getPhone().equals(request.getPhone()) && userRepository.existsByPhone(request.getPhone())) {
            throw new UserAlreadyExistsException("phone", request.getPhone());
        }
        
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setAddress(request.getAddress());
        
        User updatedUser = userRepository.save(user);
        return mapToUserResponse(updatedUser);
    }
    
    public void deactivateUser(Long id, Long currentUserId, User.Role currentUserRole) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException(id));
        
        validateUserAccess(user, currentUserId, currentUserRole);
        
        if (user.getStatus() == User.UserStatus.INACTIVE) {
            throw new UserStatusException("User is already inactive");
        }
        
        user.setStatus(User.UserStatus.INACTIVE);
        userRepository.save(user);
    }
    
    private void validateRegistrationRequest(UserRegistrationRequest request, Long currentUserId) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("email", request.getEmail());
        }
        
        if (userRepository.existsByPhone(request.getPhone())) {
            throw new UserAlreadyExistsException("phone", request.getPhone());
        }
        
        // Validate role hierarchy if parent is specified
        if (request.getParentId() != null) {
            User parent = userRepository.findById(request.getParentId())
                .orElseThrow(() -> new UserNotFoundException(request.getParentId()));
            
            if (parent.getStatus() != User.UserStatus.ACTIVE) {
                throw new UserStatusException("Cannot add user under inactive parent");
            }
            
            validateRoleHierarchy(parent.getRole(), request.getRole());
        }
    }
    
    private void validateRoleHierarchy(User.Role parentRole, User.Role childRole) {
        switch (parentRole) {
            case ADMIN:
                if (childRole == User.Role.ADMIN) {
                    throw new InvalidRoleHierarchyException("Admin cannot add another admin");
                }
                break;
            case SUPER_DISTRIBUTOR:
                if (childRole != User.Role.DISTRIBUTOR && childRole != User.Role.RETAILER) {
                    throw new InvalidRoleHierarchyException(parentRole, childRole);
                }
                break;
            case DISTRIBUTOR:
                if (childRole != User.Role.RETAILER) {
                    throw new InvalidRoleHierarchyException(parentRole, childRole);
                }
                break;
            case RETAILER:
                throw new InvalidRoleHierarchyException("Retailer cannot add users");
        }
    }
    
    private void validateUserAccess(User user, Long currentUserId, User.Role currentUserRole) {
        if (currentUserRole == User.Role.ADMIN) {
            return; // Admin has access to all users
        }
        
        // Users can access their own data
        if (user.getId().equals(currentUserId)) {
            return;
        }
        
        // Check if current user is in the hierarchy of the requested user
        if (!isInHierarchy(user.getId(), currentUserId)) {
            throw new UnauthorizedAccessException("You can only access users in your hierarchy");
        }
    }
    
    private void validateHierarchyAccess(Long parentId, Long currentUserId, User.Role currentUserRole) {
        if (currentUserRole == User.Role.ADMIN) {
            return; // Admin has access to all hierarchies
        }
        
        if (!parentId.equals(currentUserId)) {
            throw new UnauthorizedAccessException("You can only view your own hierarchy");
        }
    }
    
    private boolean isInHierarchy(Long userId, Long currentUserId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) return false;
        
        Long parentId = user.getParentId();
        while (parentId != null) {
            if (parentId.equals(currentUserId)) {
                return true;
            }
            User parent = userRepository.findById(parentId).orElse(null);
            if (parent == null) break;
            parentId = parent.getParentId();
        }
        return false;
    }
    
    private UserResponse mapToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setId(user.getId());
        response.setName(user.getName());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setAddress(user.getAddress());
        response.setRole(user.getRole());
        response.setParentId(user.getParentId());
        response.setStatus(user.getStatus());
        response.setCreatedAt(user.getCreatedAt());
        response.setUpdatedAt(user.getUpdatedAt());
        return response;
    }
    
    public Boolean userExists(Long userId) {
        return userRepository.existsById(userId);
    }
    
    private Long generateUniqueUserId() {
        Long userId;
        do {
            userId = 10000000L + (long) (Math.random() * 90000000L);
        } while (userRepository.existsById(userId));
        return userId;
    }
}