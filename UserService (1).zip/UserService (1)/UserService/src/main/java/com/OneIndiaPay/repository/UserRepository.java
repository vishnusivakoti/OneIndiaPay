package com.OneIndiaPay.repository;

import com.OneIndiaPay.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByEmail(String email);
    
    Optional<User> findByPhone(String phone);
    
    boolean existsByEmail(String email);
    
    boolean existsByPhone(String phone);
    
    List<User> findByParentId(Long parentId);
    
    @Query("SELECT u FROM User u WHERE u.parentId = :parentId")
    List<User> findDirectChildren(@Param("parentId") Long parentId);
    
    @Query("SELECT u FROM User u WHERE u.role = :role AND u.status = 'ACTIVE'")
    List<User> findByRoleAndActiveStatus(@Param("role") User.Role role);
}