package com.OneIndiaPay.exception;

import com.OneIndiaPay.entity.User;

public class UserStatusException extends RuntimeException {
    public UserStatusException(User.UserStatus status) {
        super(String.format("Cannot perform operation on user with status: %s", status.name()));
    }
    
    public UserStatusException(String message) {
        super(message);
    }
}