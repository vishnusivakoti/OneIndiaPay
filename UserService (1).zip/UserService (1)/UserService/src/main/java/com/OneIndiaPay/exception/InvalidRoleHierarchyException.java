package com.OneIndiaPay.exception;

import com.OneIndiaPay.entity.User;

public class InvalidRoleHierarchyException extends RuntimeException {
    public InvalidRoleHierarchyException(User.Role parentRole, User.Role childRole) {
        super(String.format("%s cannot add %s. Invalid role hierarchy.", 
            parentRole.name(), childRole.name()));
    }
    
    public InvalidRoleHierarchyException(String message) {
        super(message);
    }
}