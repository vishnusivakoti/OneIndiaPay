-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(15) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    pan VARCHAR(255) NOT NULL,
    aadhaar VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN', 'SUPER_DISTRIBUTOR', 'DISTRIBUTOR', 'RETAILER')),
    parent_id BIGINT REFERENCES users(id),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'PENDING', 'SUSPENDED')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_parent_id ON users(parent_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- Insert default admin user (password: admin123)
INSERT INTO users (id, name, email, phone, password, pan, aadhaar, address, role, status) 
VALUES (10000001, 'System Admin', 'admin@oneindiapay.com', '9999999999', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9P2.nRZ.3.ByKO6', 'ADMIN1234A', '123456789012', 'Admin Address, City, State', 'ADMIN', 'ACTIVE')
ON CONFLICT (email) DO NOTHING;