# User Service - One India Pay

## Overview
The User Service manages user registration, role-based hierarchy, and user status for the One India Pay fintech application.

## Features
- **Role-based User Management**: Admin, Super Distributor, Distributor, Retailer
- **Hierarchical User Structure**: Users can add subordinates based on their role
- **User Status Management**: Active, Inactive, Pending, Suspended status tracking
- **JWT Authentication**: Secure API endpoints with role-based access
- **Custom Exceptions**: Meaningful error messages for better debugging
- **Data Validation**: Comprehensive input validation and error handling

## Architecture
- **Spring Boot 3.5.7** with Java 17
- **PostgreSQL** database with JPA/Hibernate
- **Spring Security** with JWT authentication
- **Eureka Client** for service discovery
- **RESTful APIs** with proper HTTP status codes

## Database Schema

### Users Table
- `id`: Primary key
- `name`: User full name
- `email`: Unique email address
- `phone`: Unique phone number
- `password`: Encrypted password
- `role`: User role (ADMIN, SUPER_DISTRIBUTOR, DISTRIBUTOR, RETAILER)
- `parent_id`: Reference to parent user (hierarchy)
- `status`: User status (ACTIVE, INACTIVE, PENDING, SUSPENDED)
- `created_at`: Record creation timestamp
- `updated_at`: Record update timestamp

## API Endpoints

### User Management
- `POST /users/register` - Register new user
- `GET /users/{id}` - Get user details
- `GET /users/hierarchy/{id}` - Get users under a parent
- `PUT /users/{id}` - Update user info
- `DELETE /users/{id}` - Deactivate user

## Business Rules

### Role Hierarchy
- **Admin**: Can add Super Distributors, Distributors, Retailers
- **Super Distributor**: Can add Distributors and Retailers
- **Distributor**: Can add Retailers only
- **Retailer**: Cannot add users

### User Status Management
- Users can be in ACTIVE, INACTIVE, PENDING, or SUSPENDED status
- Only active users can perform operations
- Inactive users cannot be updated or used as parents

### Access Control
- Admin has access to all data
- Super Distributors can access users they added
- Distributors can access retailers they added
- Users can access their own data

## Setup Instructions

### Prerequisites
- Java 17+
- PostgreSQL 12+
- Maven 3.6+

### Database Setup
1. Create PostgreSQL database: `oneindiapay_user`
2. Update database credentials in `application.properties`
3. Run the application - tables will be created automatically

### Environment Variables
```bash
DB_USERNAME=postgres
DB_PASSWORD=your_password
JWT_SECRET=your_jwt_secret_key_minimum_32_characters
```

### Running the Service
```bash
mvn clean install
mvn spring-boot:run
```

The service will start on port 8081 and register with Eureka on port 8761.

## Security Features
- Password encryption using BCrypt
- JWT token-based authentication
- Role-based access control
- Input validation and sanitization
- SQL injection prevention
- Audit logging for critical operations

## Testing
Default admin credentials:
- Email: admin@oneindiapay.com
- Password: admin123

## Production Considerations
- Use environment-specific configuration
- Enable SSL/TLS in production
- Configure proper logging levels
- Set up monitoring and health checks
- Use connection pooling for database
- Implement rate limiting
- Add comprehensive audit logging