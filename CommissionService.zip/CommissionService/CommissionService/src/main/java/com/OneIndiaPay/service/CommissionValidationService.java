package com.OneIndiaPay.service;

import com.OneIndiaPay.entity.Commission;
import com.OneIndiaPay.exception.UnauthorizedCommissionAccessException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CommissionValidationService {
    
    private static final Long ADMIN_USER_ID = 10000001L;
    
    public void validateAdminAccess(Long currentUserId) {
        if (!ADMIN_USER_ID.equals(currentUserId)) {
            throw new UnauthorizedCommissionAccessException(
                "Only admin can update admin commission rates");
        }
    }
    
    public void validateParentCommissionUpdate(Commission commission, Long currentUserId) {
        // Only admin or the parent can update parent commission
        if (!ADMIN_USER_ID.equals(currentUserId) && 
            !commission.getParentId().equals(currentUserId)) {
            throw new UnauthorizedCommissionAccessException(
                "You can only update parent commission for your children");
        }
        
        if (commission.getStatus() != Commission.CommissionStatus.ACTIVE) {
            throw new IllegalStateException("Cannot update inactive commission");
        }
        
        if (commission.getParentId() == null) {
            throw new IllegalStateException("User has no parent, cannot set parent commission");
        }
    }
}