package com.OneIndiaPay.repository;

import com.OneIndiaPay.entity.Commission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommissionRepository extends JpaRepository<Commission, Long> {
    
    Optional<Commission> findByUserId(Long userId);
    
    List<Commission> findByParentId(Long parentId);
    
    boolean existsByUserId(Long userId);
    
    @Query("SELECT c FROM Commission c WHERE c.userId = :userId AND c.status = 'ACTIVE'")
    Optional<Commission> findActiveCommissionByUserId(@Param("userId") Long userId);
    
    @Query("SELECT c FROM Commission c WHERE c.parentId = :parentId AND c.status = 'ACTIVE'")
    List<Commission> findActiveCommissionsByParentId(@Param("parentId") Long parentId);
    
    @Query("SELECT c FROM Commission c WHERE c.userId != 10000001 AND c.status = 'ACTIVE'")
    List<Commission> findAllNonAdminActiveCommissions();
}