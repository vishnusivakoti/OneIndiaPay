package com.OneIndiaPay.service;

import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.entity.Commission;
import com.OneIndiaPay.entity.DefaultCommission;
import com.OneIndiaPay.exception.*;
import com.OneIndiaPay.repository.CommissionRepository;
import com.OneIndiaPay.repository.DefaultCommissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class CommissionService {
    
    private final CommissionRepository commissionRepository;
    private final CommissionCalculationService calculationService;
    private final CommissionValidationService validationService;
    private final UserHierarchyService userHierarchyService;
    private final DefaultCommissionRepository defaultCommissionRepository;
    
    // private static final Long ADMIN_USER_ID = 10000001L;
    
    public CommissionResponse setCommission(CommissionRequest request, Long currentUserId) {
        // Only admin can set commissions
        validationService.validateAdminAccess(currentUserId);
        
        if (commissionRepository.existsByUserId(request.getUserId())) {
            throw new CommissionAlreadyExistsException(request.getUserId());
        }
        
        // Get default admin commission rate
        BigDecimal defaultAdminRate = getDefaultAdminCommission();
        
        Commission commission = new Commission();
        commission.setUserId(request.getUserId());
        commission.setAdminCommissionRate(defaultAdminRate);
        commission.setParentCommissionRate(request.getParentCommissionRate());
        commission.setParentId(request.getParentId());
        commission.setStatus(Commission.CommissionStatus.ACTIVE);
        
        Commission savedCommission = commissionRepository.save(commission);
        return mapToResponse(savedCommission);
    }
    
    public BigDecimal setDefaultAdminCommission(DefaultCommissionRequest request, Long currentUserId) {
        validationService.validateAdminAccess(currentUserId);
        
        DefaultCommission defaultCommission = defaultCommissionRepository
            .findByCommissionType("ADMIN_DEFAULT")
            .orElse(new DefaultCommission());
        
        defaultCommission.setCommissionType("ADMIN_DEFAULT");
        defaultCommission.setCommissionRate(request.getDefaultAdminCommissionRate());
        
        DefaultCommission saved = defaultCommissionRepository.save(defaultCommission);
        return saved.getCommissionRate();
    }
    
    public BigDecimal getDefaultAdminCommission() {
        return defaultCommissionRepository
            .findByCommissionType("ADMIN_DEFAULT")
            .map(DefaultCommission::getCommissionRate)
            .orElse(new BigDecimal("2.00"));
    }
    
    public CommissionResponse createAutoCommission(AutoCommissionRequest request) {
        if (commissionRepository.existsByUserId(request.getUserId())) {
            throw new CommissionAlreadyExistsException(request.getUserId());
        }
        
        BigDecimal defaultAdminRate = getDefaultAdminCommission();
        BigDecimal parentRate = request.getParentId() != null ? BigDecimal.ZERO : BigDecimal.ZERO;
        
        Commission commission = new Commission();
        commission.setUserId(request.getUserId());
        commission.setAdminCommissionRate(defaultAdminRate);
        commission.setParentCommissionRate(parentRate);
        commission.setParentId(request.getParentId());
        commission.setStatus(Commission.CommissionStatus.ACTIVE);
        
        Commission savedCommission = commissionRepository.save(commission);
        return mapToResponse(savedCommission);
    }
    
    public CommissionResponse updateAdminCommission(AdminCommissionUpdateRequest request, Long currentUserId) {
        validationService.validateAdminAccess(currentUserId);
        
        if (request.getApplyToAll()) {
            return updateAllAdminCommissions(request.getAdminCommissionRate());
        } else {
            return updateSingleAdminCommission(request.getSpecificUserId(), request.getAdminCommissionRate());
        }
    }
    
    public CommissionResponse updateParentCommission(ParentCommissionUpdateRequest request, Long currentUserId) {
        // Fetch user details to verify parent ID
        UserResponse user = userHierarchyService.getUserDetails(request.getUserId());
        if (user == null) {
            throw new RuntimeException("User not found: " + request.getUserId());
        }
        
        // Verify parent ID matches
        if (!request.getParentId().equals(user.getParentId())) {
            throw new UnauthorizedCommissionAccessException(
                "Parent ID mismatch. You are not authorized to update commission for this user.");
        }
        
        // Verify current user is the parent
        if (!currentUserId.equals(request.getParentId())) {
            throw new UnauthorizedCommissionAccessException(
                "Only the parent can update parent commission rates.");
        }
        
        Commission commission = commissionRepository.findByUserId(request.getUserId())
            .orElseThrow(() -> new CommissionNotFoundException(request.getUserId()));
        
        commission.setParentCommissionRate(request.getParentCommissionRate());
        Commission updatedCommission = commissionRepository.save(commission);
        
        return mapToResponse(updatedCommission);
    }
    
    public CommissionResponse getCommission(Long userId) {
        Commission commission = commissionRepository.findActiveCommissionByUserId(userId)
            .orElseThrow(() -> new CommissionNotFoundException(userId));
        
        return mapToResponse(commission);
    }
    
    public CommissionCalculationResponse calculateCommission(CommissionCalculationRequest request) {
        return calculationService.calculateCommissionSplit(request.getUserId(), request.getTransactionAmount());
    }
    
    private CommissionResponse updateAllAdminCommissions(BigDecimal adminCommissionRate) {
        List<Commission> allCommissions = commissionRepository.findAllNonAdminActiveCommissions();
        
        for (Commission commission : allCommissions) {
            commission.setAdminCommissionRate(adminCommissionRate);
        }
        
        commissionRepository.saveAll(allCommissions);
        
        // Return a sample response indicating bulk update
        CommissionResponse response = new CommissionResponse();
        response.setAdminCommissionRate(adminCommissionRate);
        return response;
    }
    
    private CommissionResponse updateSingleAdminCommission(Long userId, BigDecimal adminCommissionRate) {
        Commission commission = commissionRepository.findByUserId(userId)
            .orElseThrow(() -> new CommissionNotFoundException(userId));
        
        commission.setAdminCommissionRate(adminCommissionRate);
        Commission updatedCommission = commissionRepository.save(commission);
        
        return mapToResponse(updatedCommission);
    }
    
    private CommissionResponse mapToResponse(Commission commission) {
        CommissionResponse response = new CommissionResponse();
        response.setId(commission.getId());
        response.setUserId(commission.getUserId());
        response.setAdminCommissionRate(commission.getAdminCommissionRate());
        response.setParentCommissionRate(commission.getParentCommissionRate());
        response.setParentId(commission.getParentId());
        response.setStatus(commission.getStatus());
        response.setCreatedAt(commission.getCreatedAt());
        response.setUpdatedAt(commission.getUpdatedAt());
        return response;
    }
}