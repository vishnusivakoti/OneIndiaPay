package com.OneIndiaPay.exception;

public class CommissionNotFoundException extends RuntimeException {
    public CommissionNotFoundException(Long userId) {
        super(String.format("Commission not found for user ID: %d", userId));
    }
    
    public CommissionNotFoundException(String message) {
        super(message);
    }
}