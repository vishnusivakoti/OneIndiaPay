package com.OneIndiaPay.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class CommissionCalculationResponse {
    private Long userId;
    private BigDecimal transactionAmount;
    private BigDecimal userAmount;
    private BigDecimal totalCommission;
    private List<CommissionSplit> commissionSplits;
    
    @Data
    public static class CommissionSplit {
        private Long userId;
        private BigDecimal commissionRate;
        private BigDecimal commissionAmount;
        private String userRole;
    }
}