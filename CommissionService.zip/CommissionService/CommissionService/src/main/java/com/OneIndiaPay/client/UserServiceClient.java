package com.OneIndiaPay.client;

import com.OneIndiaPay.dto.UserResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

// @FeignClient(name = "UserService", url = "http://localhost:8081")
@FeignClient(name = "USERSERVICE")
public interface UserServiceClient {
    
    @GetMapping("/users/{id}")
    UserResponse getUserById(@PathVariable Long id);
    
    @GetMapping("/users/hierarchy/{parentId}")
    List<UserResponse> getUserHierarchy(@PathVariable Long parentId);
}