package com.OneIndiaPay.exception;

public class UnauthorizedCommissionAccessException extends RuntimeException {
    public UnauthorizedCommissionAccessException() {
        super("You don't have permission to modify this commission");
    }
    
    public UnauthorizedCommissionAccessException(String message) {
        super(message);
    }
}