package com.OneIndiaPay.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class AdminCommissionUpdateRequest {
    
    @NotNull(message = "Admin commission rate is required")
    @DecimalMin(value = "0.0", message = "Admin commission rate must be positive")
    @DecimalMax(value = "100.0", message = "Admin commission rate cannot exceed 100%")
    @Digits(integer = 3, fraction = 2, message = "Admin commission rate must have at most 3 digits before and 2 digits after decimal")
    private BigDecimal adminCommissionRate;
    
    @NotNull(message = "Apply to all flag is required")
    private Boolean applyToAll;
    
    private Long specificUserId; // Only used when applyToAll is false
}