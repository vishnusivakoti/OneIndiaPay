package com.OneIndiaPay.exception;

public class CommissionAlreadyExistsException extends RuntimeException {
    public CommissionAlreadyExistsException(Long userId) {
        super(String.format("Commission already exists for user ID: %d", userId));
    }
}