package com.OneIndiaPay.service;

import com.OneIndiaPay.client.UserServiceClient;
import com.OneIndiaPay.dto.UserResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserHierarchyService {
    
    private final UserServiceClient userServiceClient;
    
    public List<Long> getUserHierarchy(Long userId) {
        List<Long> hierarchy = new ArrayList<>();
        
        try {
            UserResponse user = userServiceClient.getUserById(userId);
            hierarchy.add(userId);
            
            // Add parent to hierarchy if exists
            if (user.getParentId() != null) {
                hierarchy.add(user.getParentId());
            }
            
        } catch (Exception e) {
            // Fallback: just return the user itself
            hierarchy.add(userId);
        }
        
        return hierarchy;
    }
    
    public UserResponse getUserDetails(Long userId) {
        try {
            return userServiceClient.getUserById(userId);
        } catch (Exception e) {
            // Return null if user not found
            return null;
        }
    }
}