package com.OneIndiaPay.repository;

import com.OneIndiaPay.entity.DefaultCommission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DefaultCommissionRepository extends JpaRepository<DefaultCommission, Long> {
    
    Optional<DefaultCommission> findByCommissionType(String commissionType);
}