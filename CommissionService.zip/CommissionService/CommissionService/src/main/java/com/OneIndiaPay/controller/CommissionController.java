package com.OneIndiaPay.controller;

import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.service.CommissionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/commissions")
@RequiredArgsConstructor
public class CommissionController {
    
    private final CommissionService commissionService;
    
    @PostMapping
    public ResponseEntity<CommissionResponse> setCommission(
            @Valid @RequestBody CommissionRequest request,
            @RequestParam(defaultValue = "10000001") Long currentUserId) {
        
        CommissionResponse response = commissionService.setCommission(request, currentUserId);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @PutMapping("/admin")
    public ResponseEntity<CommissionResponse> updateAdminCommission(
            @Valid @RequestBody AdminCommissionUpdateRequest request,
            @RequestParam Long currentUserId) {
        
        CommissionResponse response = commissionService.updateAdminCommission(request, currentUserId);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/parent")
    public ResponseEntity<CommissionResponse> updateParentCommission(
            @Valid @RequestBody ParentCommissionUpdateRequest request,
            @RequestParam Long currentUserId) {
        
        CommissionResponse response = commissionService.updateParentCommission(request, currentUserId);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/{userId}")
    public ResponseEntity<CommissionResponse> getCommission(@PathVariable Long userId) {
        CommissionResponse response = commissionService.getCommission(userId);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/calculate")
    public ResponseEntity<CommissionCalculationResponse> calculateCommission(
            @Valid @RequestBody CommissionCalculationRequest request) {
        
        CommissionCalculationResponse response = commissionService.calculateCommission(request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/default-admin")
    public ResponseEntity<BigDecimal> setDefaultAdminCommission(
            @Valid @RequestBody DefaultCommissionRequest request,
            @RequestParam(defaultValue = "10000001") Long currentUserId) {
        
        BigDecimal rate = commissionService.setDefaultAdminCommission(request, currentUserId);
        return ResponseEntity.ok(rate);
    }
    //Setting up default commission rate 
    @GetMapping("/default-admin")
    public ResponseEntity<BigDecimal> getDefaultAdminCommission() {
        BigDecimal rate = commissionService.getDefaultAdminCommission();
        return ResponseEntity.ok(rate);
    }
    //Setting up commission for self registered
    @PostMapping("/auto")
    public ResponseEntity<CommissionResponse> createAutoCommission(
            @Valid @RequestBody AutoCommissionRequest request) {
        
        CommissionResponse response = commissionService.createAutoCommission(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}