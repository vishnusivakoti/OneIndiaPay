package com.OneIndiaPay.service;

import com.OneIndiaPay.dto.CommissionCalculationResponse;
import com.OneIndiaPay.dto.UserResponse;
import com.OneIndiaPay.entity.Commission;
import com.OneIndiaPay.repository.CommissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommissionCalculationService {
    
    private final CommissionRepository commissionRepository;
    private final UserHierarchyService userHierarchyService;
    
    private static final BigDecimal ADMIN_COMMISSION_RATE = new BigDecimal("2.00");
    
    public CommissionCalculationResponse calculateCommissionSplit(Long userId, BigDecimal transactionAmount) {
        List<CommissionCalculationResponse.CommissionSplit> splits = new ArrayList<>();
        BigDecimal totalCommission = BigDecimal.ZERO;
        
        Commission commission = commissionRepository.findActiveCommissionByUserId(userId)
            .orElse(null);
        
        if (commission != null) {
            // Calculate admin commission
            if (commission.getAdminCommissionRate() != null) {
                BigDecimal adminCommissionAmount = transactionAmount
                    .multiply(commission.getAdminCommissionRate())
                    .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                
                CommissionCalculationResponse.CommissionSplit adminSplit = new CommissionCalculationResponse.CommissionSplit();
                adminSplit.setUserId(10000001L);
                adminSplit.setCommissionRate(commission.getAdminCommissionRate());
                adminSplit.setCommissionAmount(adminCommissionAmount);
                adminSplit.setUserRole("ADMIN");
                
                splits.add(adminSplit);
                totalCommission = totalCommission.add(adminCommissionAmount);
            }
            
            // Calculate parent commission if exists
            if (commission.getParentCommissionRate() != null && commission.getParentId() != null) {
                BigDecimal parentCommissionAmount = transactionAmount
                    .multiply(commission.getParentCommissionRate())
                    .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                
                CommissionCalculationResponse.CommissionSplit parentSplit = new CommissionCalculationResponse.CommissionSplit();
                parentSplit.setUserId(commission.getParentId());
                parentSplit.setCommissionRate(commission.getParentCommissionRate());
                parentSplit.setCommissionAmount(parentCommissionAmount);
                parentSplit.setUserRole(getUserRole(commission.getParentId()));
                
                splits.add(parentSplit);
                totalCommission = totalCommission.add(parentCommissionAmount);
            }
        } else {
            // Add default admin commission if no commission record exists
            BigDecimal adminCommissionAmount = transactionAmount
                .multiply(ADMIN_COMMISSION_RATE)
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
            
            CommissionCalculationResponse.CommissionSplit adminSplit = new CommissionCalculationResponse.CommissionSplit();
            adminSplit.setUserId(10000001L);
            adminSplit.setCommissionRate(ADMIN_COMMISSION_RATE);
            adminSplit.setCommissionAmount(adminCommissionAmount);
            adminSplit.setUserRole("ADMIN");
            
            splits.add(adminSplit);
            totalCommission = adminCommissionAmount;
        }
        
        BigDecimal userAmount = transactionAmount.subtract(totalCommission);
        
        CommissionCalculationResponse response = new CommissionCalculationResponse();
        response.setUserId(userId);
        response.setTransactionAmount(transactionAmount);
        response.setUserAmount(userAmount);
        response.setTotalCommission(totalCommission);
        response.setCommissionSplits(splits);
        
        return response;
    }
    
    private String getUserRole(Long userId) {
        try {
            UserResponse user = userHierarchyService.getUserDetails(userId);
            return user != null ? user.getRole() : "USER";
        } catch (Exception e) {
            return "USER";
        }
    }
}