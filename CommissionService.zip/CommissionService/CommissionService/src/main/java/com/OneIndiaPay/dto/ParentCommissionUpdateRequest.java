package com.OneIndiaPay.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ParentCommissionUpdateRequest {
    
    @NotNull(message = "User ID is required")
    private Long userId;
    
    @NotNull(message = "Parent ID is required")
    private Long parentId;
    
    @NotNull(message = "Parent commission rate is required")
    @DecimalMin(value = "0.0", message = "Parent commission rate must be positive")
    @DecimalMax(value = "100.0", message = "Parent commission rate cannot exceed 100%")
    @Digits(integer = 3, fraction = 2, message = "Parent commission rate must have at most 3 digits before and 2 digits after decimal")
    private BigDecimal parentCommissionRate;
}