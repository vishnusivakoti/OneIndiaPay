package com.OneIndiaPay.dto;

import com.OneIndiaPay.entity.Commission;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CommissionResponse {
    private Long id;
    private Long userId;
    private BigDecimal adminCommissionRate;
    private BigDecimal parentCommissionRate;
    private Long parentId;
    private Commission.CommissionStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}