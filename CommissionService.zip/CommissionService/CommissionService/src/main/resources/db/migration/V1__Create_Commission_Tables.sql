-- Create commissions table
CREATE TABLE IF NOT EXISTS commissions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    admin_commission_rate DECIMAL(5,2) NOT NULL CHECK (admin_commission_rate >= 0 AND admin_commission_rate <= 100),
    parent_commission_rate DECIMAL(5,2) CHECK (parent_commission_rate >= 0 AND parent_commission_rate <= 100),
    parent_id BIGINT,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_commissions_user_id ON commissions(user_id);
CREATE INDEX IF NOT EXISTS idx_commissions_parent_id ON commissions(parent_id);
CREATE INDEX IF NOT EXISTS idx_commissions_status ON commissions(status);