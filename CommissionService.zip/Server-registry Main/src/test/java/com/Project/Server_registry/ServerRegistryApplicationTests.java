package com.Project.Server_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
