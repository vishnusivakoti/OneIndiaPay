package com.OneIndiaPay.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentResponse {
    private String orderId;
    private BigDecimal amount;
    private String currency;
    private String status;
    private String receipt;
    private Long createdAt;
}