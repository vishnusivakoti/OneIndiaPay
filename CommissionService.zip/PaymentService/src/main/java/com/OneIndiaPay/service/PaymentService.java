package com.OneIndiaPay.service;

import com.OneIndiaPay.dto.PaymentRequest;
import com.OneIndiaPay.dto.PaymentResponse;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class PaymentService {
    
    private final RazorpayClient razorpayClient;
    
    public PaymentResponse createOrder(PaymentRequest request) throws RazorpayException {
        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", request.getAmount().multiply(new BigDecimal("100")).intValue()); // Convert to paise
        orderRequest.put("currency", request.getCurrency());
        orderRequest.put("receipt", request.getReceipt());
        
        if (request.getNotes() != null && !request.getNotes().trim().isEmpty()) {
            JSONObject notes = new JSONObject();
            notes.put("description", request.getNotes());
            orderRequest.put("notes", notes);
        }
        
        Order order = razorpayClient.orders.create(orderRequest);
        
        PaymentResponse response = new PaymentResponse();
        response.setOrderId(order.get("id"));
        response.setAmount(new BigDecimal(order.get("amount").toString()).divide(new BigDecimal("100")));
        response.setCurrency(order.get("currency"));
        response.setStatus(order.get("status"));
        response.setReceipt(order.get("receipt"));
        response.setCreatedAt(Long.parseLong(order.get("created_at").toString()));
        
        return response;
    }
    
    public PaymentResponse getOrder(String orderId) throws RazorpayException {
        Order order = razorpayClient.orders.fetch(orderId);
        
        PaymentResponse response = new PaymentResponse();
        response.setOrderId(order.get("id"));
        response.setAmount(new BigDecimal(order.get("amount").toString()).divide(new BigDecimal("100")));
        response.setCurrency(order.get("currency"));
        response.setStatus(order.get("status"));
        response.setReceipt(order.get("receipt"));
        response.setCreatedAt(Long.parseLong(order.get("created_at").toString()));
        
        return response;
    }
}