package com.OneIndiaPay.client;

import com.OneIndiaPay.dto.UserResponse;
import org.springframework.stereotype.Component;

@Component
public class UserServiceFallback implements UserServiceClient {
    
    @Override
    public UserResponse getUserById(Long userId) {
        return null; // Return null when service is unavailable
    }
}