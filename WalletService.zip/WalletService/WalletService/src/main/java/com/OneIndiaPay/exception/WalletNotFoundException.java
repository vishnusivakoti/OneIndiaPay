package com.OneIndiaPay.exception;

public class WalletNotFoundException extends RuntimeException {
    public WalletNotFoundException(Long userId) {
        super(String.format("Wallet not found for user ID: %d", userId));
    }
}