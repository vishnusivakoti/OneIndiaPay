package com.OneIndiaPay.dto;

import com.OneIndiaPay.entity.Wallet;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class WalletResponse {
    private Long id;
    private Long userId;
    private BigDecimal balance;
    private Wallet.WalletStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}