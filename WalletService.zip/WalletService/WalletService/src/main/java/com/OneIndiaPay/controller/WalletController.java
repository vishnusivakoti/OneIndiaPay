package com.OneIndiaPay.controller;

import com.OneIndiaPay.client.UserServiceClient;
import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.service.WalletService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wallets")
@RequiredArgsConstructor
public class WalletController {
    
    private final WalletService walletService;
    
    @Autowired
    UserServiceClient client;
    
    @GetMapping("/user/{userId}")
    public UserResponse fetchuser(@PathVariable Long userId) {
    	UserResponse user = client.getUserById(userId);
    	return user;
    }
    
//    @PostMapping("/create/{userId}")
//    public ResponseEntity<?> createWallet(@PathVariable Long userId) {
//        try {
//            WalletResponse response = walletService.createWallet(userId);
//            return new ResponseEntity<>(response, HttpStatus.CREATED);
//        } catch (RuntimeException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body("Error: " + e.getMessage());
//        }
//    }
    @PostMapping("/create/{userId}")
    public ResponseEntity<?> createWallet(@PathVariable Long userId) {
        try {
            WalletResponse response = walletService.createWallet(userId);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body("Error: " + e.getMessage());
        }
    }
    
    @GetMapping("/{userId}")
    public ResponseEntity<WalletResponse> getWallet(@PathVariable Long userId) {
        WalletResponse response = walletService.getWallet(userId);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/credit")
    public ResponseEntity<WalletResponse> creditWallet(
            @Valid @RequestBody WalletTransactionRequest request) {
        
        WalletResponse response = walletService.creditWallet(request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/debit")
    public ResponseEntity<WalletResponse> debitWallet(
            @Valid @RequestBody WalletTransactionRequest request) {
        
        WalletResponse response = walletService.debitWallet(request);
        return ResponseEntity.ok(response);
    }
}