package com.OneIndiaPay.client;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.stereotype.Component;

@Component
public class CustomErrorDecoder implements ErrorDecoder {
    
    @Override
    public Exception decode(String methodKey, Response response) {
        if (response.status() == 500) {
            return new RuntimeException("UserService internal error - unable to fetch user details");
        }
        if (response.status() == 404) {
            return new RuntimeException("User not found in UserService");
        }
        return new Default().decode(methodKey, response);
    }
}