package com.OneIndiaPay.repository;

import com.OneIndiaPay.entity.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WalletRepository extends JpaRepository<Wallet, Long> {
    
    Optional<Wallet> findByUserId(Long userId);
    
    boolean existsByUserId(Long userId);
    
    @Query("SELECT w FROM Wallet w WHERE w.userId = :userId AND w.status = 'ACTIVE'")
    Optional<Wallet> findActiveWalletByUserId(@Param("userId") Long userId);
}