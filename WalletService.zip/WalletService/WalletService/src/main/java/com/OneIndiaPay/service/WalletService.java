package com.OneIndiaPay.service;

import com.OneIndiaPay.client.UserServiceClient;
import com.OneIndiaPay.dto.*;
import com.OneIndiaPay.entity.Wallet;
import com.OneIndiaPay.exception.*;
import com.OneIndiaPay.repository.WalletRepository;
import com.OneIndiaPay.util.EncryptionUtil;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
@Transactional
public class WalletService {
    
    private final WalletRepository walletRepository;
    private final EncryptionUtil encryptionUtil;
    private final UserServiceClient userServiceClient;
    
//    public WalletResponse createWallet(Long userId) {
//        // Fetch user record from UserService to verify existence
//        try {
//            UserResponse user = userServiceClient.getUserById(userId);
//            System.out.println(user);
//            if (user == null || user.getId() == null) {
//                throw new UserNotFoundException(userId);
//            }
//        } catch (feign.FeignException.NotFound e) {
//            throw new UserNotFoundException(userId);
//        } catch (Exception e) {
//            // For testing: Skip user validation if UserService is down
//            System.out.println("Warning: UserService unavailable, proceeding without validation");
//        }
       
//        if (walletRepository.existsByUserId(userId)) {
//            throw new RuntimeException("Wallet already exists for user: " + userId);
//        }
       
//        Wallet wallet = new Wallet();
//        wallet.setUserId(userId);
//        wallet.setEncryptedBalance(encryptionUtil.encrypt("0.00"));
//        wallet.setStatus(Wallet.WalletStatus.ACTIVE);
       
//        Wallet savedWallet = walletRepository.save(wallet);
//        return mapToResponse(savedWallet);
//    }
    
    public WalletResponse createWallet(Long userId) {
        // Validate userId
        if (userId == null || userId <= 0) {
            throw new IllegalArgumentException("Invalid userId: must be positive number");
        }
        
        // Fetch and validate user from UserService
        UserResponse user;
        try {
            user = userServiceClient.getUserById(userId);
        } catch (feign.FeignException.NotFound e) {
            throw new UserNotFoundException(userId);
        } catch (Exception e) {
            throw new RuntimeException("Unable to verify user existence. UserService unavailable.");
        }
        
        if (user == null || user.getId() == null) {
            throw new UserNotFoundException(userId);
        }
        
        // Validate user status
        if ("INACTIVE".equals(user.getStatus())) {
            throw new RuntimeException("Cannot create wallet for inactive user: " + userId);
        }
        
        // Check if wallet already exists
        if (walletRepository.existsByUserId(userId)) {
            throw new RuntimeException("Wallet already exists for user: " + userId);
        }
        
        // Create and save wallet
        Wallet wallet = new Wallet();
        wallet.setUserId(userId);
        wallet.setEncryptedBalance(encryptionUtil.encrypt("0.00"));
        wallet.setStatus(Wallet.WalletStatus.ACTIVE);
        
        Wallet savedWallet = walletRepository.save(wallet);
        return mapToResponse(savedWallet);
    }
    
    
    public WalletResponse getWallet(Long userId) {
        Wallet wallet = walletRepository.findActiveWalletByUserId(userId)
            .orElseThrow(() -> new WalletNotFoundException(userId));
        
        return mapToResponse(wallet);
    }
    
    public WalletResponse creditWallet(WalletTransactionRequest request) {
        Wallet wallet = walletRepository.findActiveWalletByUserId(request.getUserId())
            .orElseThrow(() -> new WalletNotFoundException(request.getUserId()));
        
        BigDecimal currentBalance = new BigDecimal(encryptionUtil.decrypt(wallet.getEncryptedBalance()));
        BigDecimal newBalance = currentBalance.add(request.getAmount());
        wallet.setEncryptedBalance(encryptionUtil.encrypt(newBalance.toString()));
        
        Wallet updatedWallet = walletRepository.save(wallet);
        return mapToResponse(updatedWallet);
    }
    
    public WalletResponse debitWallet(WalletTransactionRequest request) {
        Wallet wallet = walletRepository.findActiveWalletByUserId(request.getUserId())
            .orElseThrow(() -> new WalletNotFoundException(request.getUserId()));
        
        BigDecimal currentBalance = new BigDecimal(encryptionUtil.decrypt(wallet.getEncryptedBalance()));
        
        if (currentBalance.compareTo(request.getAmount()) < 0) {
            throw new InsufficientBalanceException(currentBalance, request.getAmount());
        }
        
        BigDecimal newBalance = currentBalance.subtract(request.getAmount());
        wallet.setEncryptedBalance(encryptionUtil.encrypt(newBalance.toString()));
        
        Wallet updatedWallet = walletRepository.save(wallet);
        return mapToResponse(updatedWallet);
    }
    
    private WalletResponse mapToResponse(Wallet wallet) {
        WalletResponse response = new WalletResponse();
        response.setId(wallet.getId());
        response.setUserId(wallet.getUserId());
        response.setBalance(new BigDecimal(encryptionUtil.decrypt(wallet.getEncryptedBalance())));
        response.setStatus(wallet.getStatus());
        response.setCreatedAt(wallet.getCreatedAt());
        response.setUpdatedAt(wallet.getUpdatedAt());
        return response;
    }
}