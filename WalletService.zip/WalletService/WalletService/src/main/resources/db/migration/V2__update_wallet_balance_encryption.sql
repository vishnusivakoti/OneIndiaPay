-- Update wallet table to use encrypted balance
ALTER TABLE wallet 
DROP COLUMN balance,
ADD COLUMN encrypted_balance VARCHAR(500) NOT NULL DEFAULT 'encrypted_zero_balance';

-- Update existing records with encrypted zero balance (placeholder)
-- In production, you would need to encrypt existing balances properly
UPDATE wallet SET encrypted_balance = 'encrypted_zero_balance' WHERE encrypted_balance = 'encrypted_zero_balance';