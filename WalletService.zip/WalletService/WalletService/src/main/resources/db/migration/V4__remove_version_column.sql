-- Remove version column from wallets table
ALTER TABLE wallets DROP COLUMN IF EXISTS version;