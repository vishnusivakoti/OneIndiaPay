package com.OneIndiaPay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
